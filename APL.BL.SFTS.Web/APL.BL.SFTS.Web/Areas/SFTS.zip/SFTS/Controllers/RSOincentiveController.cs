﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace APL.BL.SFTS.Web.Areas.SFTS.Controllers
{
    public class RSOincentiveController : Controller
	{
		// GET: SFTS/Rsofixsalary
		public ActionResult Index()
		{
			return View();
		}
	}
}
