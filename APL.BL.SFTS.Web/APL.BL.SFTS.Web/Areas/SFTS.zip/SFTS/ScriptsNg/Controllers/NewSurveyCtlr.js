﻿/**
 * CurrentOfferCtrl.js
 */
app.controller('NewSurveyCtrl', ['$scope', 'crudService', 'conversion', '$filter', '$localStorage', 'uiGridConstants',
    function ($scope, crudService, conversion, $filter, $localStorage, uiGridConstants) {

        var baseUrl = '/mDMS/SFTS/api/Survey/';
                var isExisting = 0;
                var page = 0;
                var pageSize = 100;
                var isPaging = 0;
                var totalData = 0;

                $scope.btnSaveText = "Save";
                $scope.btnShowText = "Show List";

                $scope.PageTitle = 'New Survey';
                $scope.ListTitle = 'Survey List';
                $scope.IsListIcon = true;
                $scope.gridOptionsNewSurvey = [];

                $scope.IsHidden = true;
                $scope.IsShow = true;
                $scope.IsHiddenDetail = true;
                $scope.ShowHide = function () {
                    $scope.IsHidden = $scope.IsHidden == true ? false : true;
                    $scope.IsHiddenDetail = true;
                    if ($scope.IsHidden == true) {
                        $scope.btnShowText = "Show List";
                        $scope.IsShow = true;

                        $scope.IsCreateIcon = false;
                        $scope.IsListIcon = true;
                        $scope.clear();
                    }
                    else {
                        $scope.btnShowText = "Create";
                        $scope.btnSaveText = "Save";
                        $scope.IsShow = false;
                        $scope.IsHidden = false;

                        $scope.IsCreateIcon = true;
                        $scope.IsListIcon = false;
                       // loadCurrentOfferList(0);
                    }
                }

                function CommonEntity() {
                    $scope.HeaderToken = $scope.tokenManager.generateSecurityToken();
                    $scope.loggedUserId = $scope.loggedUserManager.loggedUser();
                }
                CommonEntity();


                var IsPermitted = false;
                function GetPermission(code) {
                    objcmnParam = {
                        loggeduser: $scope.loggedUserId,
                        PermissionCode: code
                    };

                    var apiRoute = '/mDMS/SFTS/api/Permission/GetRoleWisePermission/';
                    var cmnParam = "[" + JSON.stringify(objcmnParam) + "]";

                    var roleWisePermission = crudService.GetList(apiRoute, cmnParam, $scope.HeaderToken);
                    roleWisePermission.then(function (response) {
                        $scope.listRoleWisePermission = response.data.roleWisePermission;
                        IsPermitted = response.data.IsPermitted;
                        if (IsPermitted != true) {
                            window.location.href = "/mDMS/SFTS/NoPermission";
                        }
                    },
                    function (error) {
                        console.log("Error: " + error);
                    });
                }

                GetPermission('01401');


                //**********----Pagination----***************
                $scope.pagination = {
                    paginationPageSizes: [15, 25, 50, 75, 100, 500, 1000, "All"],
                    ddlpageSize: 15, pageNumber: 1, pageSize: 15, totalItems: 0,

                    getTotalPages: function () {
                        return Math.ceil(this.totalItems / this.pageSize);
                    },
                    pageSizeChange: function () {
                        if (this.ddlpageSize == "All")
                            this.pageSize = $scope.pagination.totalItems;
                        else
                            this.pageSize = this.ddlpageSize

                        this.pageNumber = 1
                        loadCustomerRecords(1);
                    },
                    firstPage: function () {
                        if (this.pageNumber > 1) {
                            this.pageNumber = 1
                            loadCustomerRecords(1);
                        }
                    },
                    nextPage: function () {
                        if (this.pageNumber < this.getTotalPages()) {
                            this.pageNumber++;
                            loadCustomerRecords(1);
                        }
                    },
                    previousPage: function () {
                        if (this.pageNumber > 1) {
                            this.pageNumber--;
                            loadCustomerRecords(1);
                        }
                    },
                    lastPage: function () {
                        if (this.pageNumber >= 1) {
                            this.pageNumber = this.getTotalPages();
                            loadCustomerRecords(1);
                        }
                    }
                };
                //  }
              
        //**********----Get Distributors ----***************
                function loadDistributors(isPaging) {
                    objcmnParam = {
                        pageNumber: page,
                        pageSize: pageSize,
                        IsPaging: isPaging,
                        DistributorID: 0,
                        //loggeduser: $scope.loggedUserId,                      
                    };

                    var apiRoute = '/mDMS/SFTS/api/CmnDropdown/GetDistributors/';
                    var cmnParam = "[" + JSON.stringify(objcmnParam) + "]";

                    var listDistributors = crudService.GetList(apiRoute, cmnParam, $scope.HeaderToken);
                    listDistributors.then(function (response) {
                        $scope.listDistributor = response.data.objListDistributor;
                    },
                    function (error) {
                        console.log("Error: " + error);
                    });
                }

                loadDistributors(0);


        //**********----Get Routes ----***************
                $scope.loadRoutes = function (isPaging) {
                    $("#ddlRoute").select2("val", "");
                    objcmnParam = {
                        pageNumber: page,
                        pageSize: pageSize,
                        IsPaging: isPaging,
                        DistributorID: $scope.Distributor,
                        RouteID: 0,
                        //loggeduser: $scope.loggedUserId,                              
                    };

                    var apiRoute = '/mDMS/SFTS/api/CmnDropdown/GetRoutes/';
                    var cmnParam = "[" + JSON.stringify(objcmnParam) + "]";

                    var listRoutes = crudService.GetList(apiRoute, cmnParam, $scope.HeaderToken);
                    listRoutes.then(function (response) {
                        $scope.listRoute = response.data.objListRoute;
                    },
                    function (error) {
                        console.log("Error: " + error);
                    });
                }

                function loadRoutes(isPaging) {
                    var apiRoute = '/mDMS/SFTS/api/CmnDropdown/GetRoutes/';
                    var cmnParam = "[" + JSON.stringify(objcmnParam) + "]";

                    var listDistributors = crudService.GetList(apiRoute, cmnParam, $scope.HeaderToken);
                    listDistributors.then(function (response) {
                        $scope.listRoute = response.data.objListRoute;
                    },
                    function (error) {
                        console.log("Error: " + error);
                    });
                }


                //**********----Get All Customer Records----***************
                function loadAllNewSurvey(isPaging) {
                    $scope.gridOptionsNewSurvey.enableFiltering = true;
                    $scope.gridOptionsNewSurvey.enableGridMenu = true;

                    // For Loading
                    if (isPaging == 0)
                        $scope.pagination.pageNumber = 1;

                    //For Loading
                    $scope.loaderMoreNewSurvey = true;
                    $scope.lblMessageForNewSurvey = 'loading please wait....!';
                    $scope.result = "color-red";

                    $scope.highlightFilteredHeader = function (row, rowRenderIndex, col, colRenderIndex) {
                        if (col.filters[0].term) {
                            return 'header-filtered';
                        } else {
                            return '';
                        }
                    };

                    $scope.gridOptionsNewSurvey = {
                        useExternalPagination: true,
                        useExternalSorting: true,
                        enableFiltering: true,
                        enableRowSelection: true,
                        enableSelectAll: true,
                        showFooter: true,
                        enableGridMenu: true,

                        columnDefs: [
                            { name: "DISTRIBUTOR_NAME", displayName: "Distributor", title: "Distributor", width: '20%', headerCellClass: $scope.highlightFilteredHeader },
                            { name: "TITLE", displayName: "Title", title: "Title", width: '20%', headerCellClass: $scope.highlightFilteredHeader },
                            { name: "DESCRIPTION", displayName: "Description", title: "Description", width: '30%', headerCellClass: $scope.highlightFilteredHeader },
                            { name: "SURVEY_STATUS", displayName: "Status", title: "Status", width: '10%', headerCellClass: $scope.highlightFilteredHeader },
                            { name: "START_DATETIME", displayName: "Start Date", title: "Start Date", width: '15%', headerCellClass: $scope.highlightFilteredHeader },
                            { name: "END_DATETIME", displayName: "End Date", title: "End Date", width: '15%', headerCellClass: $scope.highlightFilteredHeader },
                            { name: "SURVEY_FOR", displayName: "Survey For", title: "Survey For", width: '10%', headerCellClass: $scope.highlightFilteredHeader },
                            {
                                name: 'Action',
                                displayName: "Action",
                                enableColumnResizing: false,
                                enableFiltering: false,
                                enableSorting: false,
                                pinnedRight: true,
                                width: '12%',
                                headerCellClass: $scope.highlightFilteredHeader,
                                cellTemplate: '<div style="padding-left: 12px"><span class="label label-info label-mini" style="text-align:center !important;">' +
                                              '<a href="" title="Edit" ng-click="grid.appScope.getNewSurveyInfo(row.entity)">' +
                                                '<i class="icon-edit" aria-hidden="true"></i> Edit' +
                                              '</a>' +
                                              '</span>' +
                                             
                                              '<span class="label label-warning label-mini" style="text-align:center !important;">' +
                                              '<a href="" title="Delete" ng-click="grid.appScope.delete(row.entity)">' +
                                                '<i class="icon-trash" aria-hidden="true"></i> Delete' +
                                              '</a>' +
                                              '</span></div>'
                            }
                        ],

                        onRegisterApi: function (gridApi) {
                            $scope.gridApi = gridApi;
                        },
                        enableFiltering: true,
                        enableGridMenu: true,
                        enableSelectAll: true,
                        exporterCsvFilename: 'Customer.csv',
                        exporterPdfDefaultStyle: { fontSize: 9 },
                        exporterPdfTableStyle: { margin: [30, 30, 30, 30] },
                        exporterPdfTableHeaderStyle: { fontSize: 10, bold: true, italics: true, color: 'red' },
                        exporterPdfHeader: { text: "Customer", style: 'headerStyle' },
                        exporterPdfFooter: function (currentPage, pageCount) {
                            return { text: currentPage.toString() + ' of ' + pageCount.toString(), style: 'footerStyle' };
                        },
                        exporterPdfCustomFormatter: function (docDefinition) {
                            docDefinition.styles.headerStyle = { fontSize: 22, bold: true };
                            docDefinition.styles.footerStyle = { fontSize: 10, bold: true };
                            return docDefinition;
                        },
                        exporterPdfOrientation: 'portrait',
                        exporterPdfPageSize: 'LETTER',
                        exporterPdfMaxGridWidth: 500,
                        exporterCsvLinkElement: angular.element(document.querySelectorAll(".custom-csv-link-location")),
                    };

                    objcmnParam = {
                        pageNumber: page,
                        pageSize: pageSize,
                        IsPaging: isPaging,
                        //loggeduser: $scope.loggedUserId,
                    };
                    var apiRoute = baseUrl + 'GetAllSurvey/';

                    var cmnParam = "[" + JSON.stringify(objcmnParam) + "]";

                    var listCurrentOfferInfo = crudService.GetList(apiRoute, cmnParam, $scope.HeaderToken);
                    listCurrentOfferInfo.then(function (response) {
                        $scope.pagination.totalItems = response.data.recordsTotal;
                        $scope.gridOptionsNewSurvey.data = response.data.surveyList;
                        $scope.loaderMoreNewSurvey = false;
                        $scope.currentOfferList = response.data.surveyList;
                    },
                    function (error) {
                        console.log("Error: " + error);
                    });
                };

                loadAllNewSurvey(0);


        //**********----Get Single Record----***************
                $scope.getNewSurveyInfo = function (dataModel) {
                    $scope.IsShow = true;
                    $scope.IsHiddenDetail = false;
                    $scope.btnShowText = "Show List";
                    $scope.IsHidden = true;
                    $scope.btnSaveText = "Update";
                    $scope.IsCreateIcon = false;
                    $scope.IsListIcon = true;


                    $scope.hSurveyId = dataModel.SURVEYLIST_ID;
                    $scope.Title = dataModel.TITLE;
                    $scope.Description = dataModel.DESCRIPTION;
                    $scope.StartDate = dataModel.START_DATETIME;
                    $scope.EndDate = dataModel.END_DATETIME;
                    //$scope.SurveyFor = dataModel.SurveyFor;
                    

                    $("#ddlDistributor").select2("data", { id: dataModel.DISTRIBUTORID, text: dataModel.DISTRIBUTOR_NAME });
                    $("#ddlRoute").select2("data", { id: dataModel.ROUTE_CODE, text: dataModel.ROUTE_NAME });
                   //$("#ddlSurveyFor").select2("data", { id: dataModel.SurveyFor, text: dataModel.SurveyFor });




                };

    
                //**********----Create New Record----***************

                $scope.save = function () {
                    objcmnParam = {
                        loggeduser: $scope.loggedUserId,
                        PermissionCode: '01402'
                    };

                    var apiRoute = '/mDMS/SFTS/api/Permission/GetRoleWisePermission/';
                    var cmnParam = "[" + JSON.stringify(objcmnParam) + "]";
                    console.log(cmnParam);
                    var roleWisePermission = crudService.GetList(apiRoute, cmnParam, $scope.HeaderToken);
                    roleWisePermission.then(function (response) {
                        $scope.listRoleWisePermission = response.data.roleWisePermission;
                        IsPermitted = response.data.IsPermitted;
                        if (IsPermitted == true) {
                            $scope.SaveNewSurvey();
                        } else {
                            Command: toastr["warning"]("You have no permission for this operation!");
                            return;
                        }
                    },
                    function (error) {
                        console.log("Error: " + error);
                    });

                };

                $scope.SaveNewSurvey = function () {
                    objcmnParam = {
                        pageNumber: page,
                        pageSize: pageSize,
                        IsPaging: isPaging,
                        //loggeduser: $scope.loggedUserId,
                    };

                    var SurveyInfo = {
                        SurveyId: $scope.hSurveyId == undefined || $scope.hSurveyId == null ? 0 : $scope.hSurveyId,
                        DistributorId: $scope.Distributor,
                        RouteId: $scope.Route,
                        FromDate: $scope.StartDate == "" || $scope.StartDate == null ? null : conversion.getStringToDate($scope.StartDate),
                        ToDate: $scope.EndDate == "" || $scope.EndDate == null ? null : conversion.getStringToDate($scope.EndDate),
                        StatusId: $scope.Status,
                        SurveyTitle: $scope.Title,
                        Description: $scope.Description,
                        RSOMTO: $scope.RSOMTO
                    };

                    // var HedarTokenPostPut = $scope.CustomerID > 0 ? $scope.HeaderToken.put : $scope.HeaderToken.post;
                    var apiRoute = baseUrl + 'SaveUpdateSurvey/';
                    var cmnParam = "[" + JSON.stringify(objcmnParam) + "," + JSON.stringify(SurveyInfo) + "]";

                    var SaveUpdateSurvey = crudService.GetList(apiRoute, cmnParam, $scope.HeaderToken);
                    SaveUpdateSurvey.then(function (response) {
                        // debugger;
                        if (response.data != "") {
                            Command: toastr["success"]("Save  Successfully!!!!");
                            $scope.clear();
                        }
                        else if (response.data == "") {
                                Command: toastr["warning"]("Save Not Successfull!!!!");
                            $("#save").prop("disabled", false);
                        }

                    },
                    function (error) {
                        console.log("Error: " + error);
                    });
                }

               
                //**********----Delete Single Record----***************
                $scope.delete = function (dataModel) {
                    var IsConf = confirm('You are about to delete ' + dataModel.OFFER_NAME + '. Are you sure?');
                }

                //**********----Reset Record----***************
                $scope.clear = function () {
                    $scope.IsHidden = true;
                    $scope.IsShow = true;
                    $scope.IsHiddenDetail = true
                    $scope.IsCreateIcon = false;
                    $scope.IsListIcon = true;

                    $scope.btnSaveText = "Save";
                    $scope.btnShowText = "Show List";

                    $scope.hSurveyId = 0;
                    $scope.Title = '';
                    $scope.Description = '';
                    $scope.StartDate = '';
                    $scope.EndDate = '';
      
                    $("#ddlDistributor").select2("data", { id: '', text: '--Select Distributor--' });
                    $("#ddlRoute").select2("data", { id: '', text: '--Select Route--' }); 
                    $("#ddlSurveyFor").select2("data", { id: '', text: '--Survey For--' });
                    loadAllNewSurvey(0);
                };
    }]);

