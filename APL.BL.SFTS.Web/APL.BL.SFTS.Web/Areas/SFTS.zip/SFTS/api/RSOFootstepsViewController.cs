﻿using APL.BL.SFTS.DataBridgeZone;
using APL.BL.SFTS.Models.SystemCommon;
using APL.BL.SFTS.ProcessZone;
using APL.BL.SFTS.Web.Providers;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace APL.BL.SFTS.Web.Areas.SFTS.api
{
    [RoutePrefix("SFTS/api/RSOFootstepsView")]
    public class RSOFootstepsViewController : ApiController
    {
        [HttpPost, ApiAuthorization]
        public IHttpActionResult GetRsoFootsteps(object[] data)
        {
            IEnumerable<SP_GET_RSO_GPS> rsoGPS = null;

            try
            {
                vmCmnParameters objcmnParam = JsonConvert.DeserializeObject<vmCmnParameters>(data[0].ToString());

                rsoGPS = new RsoPZ().GetRsoGPS(objcmnParam.ZoneId, objcmnParam.RsoId, objcmnParam.Date);
            }
            catch (Exception e)
            {
                e.ToString();
            }
            return Json(new
            {
                rsoGPS
            });
        }
    }
}
